int update_host_performance_data(host *hst) 
{ return OK; }

int update_service_performance_data(service *svc) 
{ return OK; }

int initialize_performance_data(const char *cfgfile) 
{ return OK; }

int cleanup_performance_data(void) 
{ return OK; }
